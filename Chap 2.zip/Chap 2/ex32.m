M = [1, 2, 3; 
     4, 5, 6; 
     7, 8, 9]; 

col_products = prod(M, 1) 
row_products = prod(M, 2)